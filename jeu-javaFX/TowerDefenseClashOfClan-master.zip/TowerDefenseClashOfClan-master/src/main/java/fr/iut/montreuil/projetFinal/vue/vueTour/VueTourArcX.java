package fr.iut.montreuil.projetFinal.vue.vueTour;

import fr.iut.montreuil.projetFinal.modele.tour.Tour;
import javafx.scene.layout.Pane;

public class VueTourArcX extends VueTour {

    public VueTourArcX(Pane pane, Tour t) {
        super(pane, t, "arcX_Coc.png");
    }
}
