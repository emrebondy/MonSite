package fr.iut.montreuil.projetFinal.vue.vueEnnemi;

import fr.iut.montreuil.projetFinal.modele.Ennemi;
import javafx.scene.layout.Pane;

public class VueGolem2 extends VueEnnemi{
    public VueGolem2(Pane pane, Ennemi e) {
        super(pane, e, "golem_Coc.png");
    }
}
