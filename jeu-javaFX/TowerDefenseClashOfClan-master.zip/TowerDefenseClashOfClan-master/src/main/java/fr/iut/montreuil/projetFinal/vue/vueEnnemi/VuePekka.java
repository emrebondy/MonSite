package fr.iut.montreuil.projetFinal.vue.vueEnnemi;

import fr.iut.montreuil.projetFinal.modele.Ennemi;
import javafx.scene.layout.Pane;

public class VuePekka extends VueEnnemi {
    public VuePekka(Pane pane, Ennemi e) {
        super(pane, e, "pekka_Coc.png");
    }
}
