package fr.iut.montreuil.projetFinal.vue.vueTour;

import fr.iut.montreuil.projetFinal.modele.tour.Tour;
import javafx.scene.layout.Pane;

public class VueTourCanon extends VueTour {

    public VueTourCanon(Pane pane, Tour t) {
        super(pane, t, "canon_Coc.png");
    }
}
