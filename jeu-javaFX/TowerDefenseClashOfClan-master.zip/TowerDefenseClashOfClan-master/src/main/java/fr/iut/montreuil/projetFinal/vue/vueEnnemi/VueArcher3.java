package fr.iut.montreuil.projetFinal.vue.vueEnnemi;

import fr.iut.montreuil.projetFinal.modele.Ennemi;
import javafx.scene.layout.Pane;

public class VueArcher3 extends VueEnnemi{
    public VueArcher3(Pane pane, Ennemi e) {
        super(pane, e, "archerLvl3.png");
    }
}
