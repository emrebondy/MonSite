package fr.iut.montreuil.projetFinal.vue.vueTour;

import fr.iut.montreuil.projetFinal.modele.tour.Tour;
import javafx.scene.layout.Pane;

public class VueTourArcher extends VueTour {

    public VueTourArcher(Pane pane, Tour t) {
        super(pane, t, "tda_Coc.png");
    }
}
